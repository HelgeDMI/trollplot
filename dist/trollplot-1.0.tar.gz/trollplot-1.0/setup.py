from distutils.core import setup

setup(
    name='trollplot',
    version='1.0',
    packages=['globeplot'],
    include_package_data=True,
    url='http://www.pytroll.org',
    license='Apache 2.0',
    author='Helge Pfeiffer',
    author_email='rhp@dmi.dk',
    description='Test'
)
